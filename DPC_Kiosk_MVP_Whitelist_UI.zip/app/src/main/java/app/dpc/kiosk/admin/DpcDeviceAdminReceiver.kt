package app.dpc.kiosk.admin

import android.app.admin.DeviceAdminReceiver

class DpcDeviceAdminReceiver: DeviceAdminReceiver()
