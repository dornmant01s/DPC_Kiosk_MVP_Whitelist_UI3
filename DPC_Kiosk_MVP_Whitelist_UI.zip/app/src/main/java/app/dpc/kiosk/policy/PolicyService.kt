package app.dpc.kiosk.policy

import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.UserManager
import app.dpc.kiosk.admin.DpcDeviceAdminReceiver

class PolicyService: Service() {
  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val admin = ComponentName(this, DpcDeviceAdminReceiver::class.java)
    try {
      dpm.setLockTaskPackages(admin, arrayOf(packageName))
      dpm.addUserRestriction(admin, UserManager.DISALLOW_FACTORY_RESET)
      dpm.addUserRestriction(admin, UserManager.DISALLOW_SAFE_BOOT)
      dpm.addUserRestriction(admin, UserManager.DISALLOW_ADD_USER)
      dpm.addUserRestriction(admin, UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES)
    } catch (t: Throwable) { t.printStackTrace() }
    stopSelf(); return START_NOT_STICKY
  }
  override fun onBind(intent: Intent?): IBinder? = null
}
