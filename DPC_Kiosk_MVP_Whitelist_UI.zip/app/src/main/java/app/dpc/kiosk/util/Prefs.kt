package app.dpc.kiosk.util

import android.content.Context

object Prefs {
  private const val FILE="kiosk_prefs"
  private const val KEY_DOMAINS="domains"
  private const val KEY_PACKAGES="packages"
  private const val KEY_PIN="pin"

  fun getDomains(ctx: Context): List<String> =
    ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_DOMAINS,"google.com")!!.split(",").map{it.trim()}.filter{it.isNotEmpty()}
  fun setDomains(ctx: Context, list: List<String>) {
    ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY_DOMAINS, list.joinToString(",")).apply()
  }
  fun getPackages(ctx: Context): List<String> =
    ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_PACKAGES,"com.android.chrome")!!.split("\n".toRegex()).map{it.trim()}.filter{it.isNotEmpty()}
  fun setPackages(ctx: Context, list: List<String>) {
    ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY_PACKAGES, list.joinToString("\n")).apply()
  }
  fun getPin(ctx: Context): String =
    ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_PIN,"1234")!!
  fun setPin(ctx: Context, pin: String) {
    ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY_PIN, pin).apply()
  }
}
