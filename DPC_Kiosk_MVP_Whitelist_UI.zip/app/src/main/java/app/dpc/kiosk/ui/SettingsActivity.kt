package app.dpc.kiosk.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import app.dpc.kiosk.R
import app.dpc.kiosk.util.Prefs

class SettingsActivity: ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_settings)

    val etDomains=findViewById<EditText>(R.id.etDomains)
    val etPackages=findViewById<EditText>(R.id.etPackages)
    etDomains.setText(Prefs.getDomains(this).joinToString(", "))
    etPackages.setText(Prefs.getPackages(this).joinToString("\n"))

    findViewById<Button>(R.id.btnSaveDomains).setOnClickListener{
      val list=etDomains.text.toString().split(",").map{it.trim()}.filter{it.isNotEmpty()}
      Prefs.setDomains(this,list); Toast.makeText(this,"도메인 저장됨",Toast.LENGTH_SHORT).show()
    }
    findViewById<Button>(R.id.btnSavePackages).setOnClickListener{
      val list=etPackages.text.toString().split("\n".toRegex()).map{it.trim()}.filter{it.isNotEmpty()}
      Prefs.setPackages(this,list); Toast.makeText(this,"앱 저장됨",Toast.LENGTH_SHORT).show()
    }
  }
}
