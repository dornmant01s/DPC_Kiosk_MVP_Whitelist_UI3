package app.dpc.kiosk.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import app.dpc.kiosk.R
import app.dpc.kiosk.util.Prefs

class LauncherActivity: ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_launcher)

    val rv = findViewById<RecyclerView>(R.id.appList)
    rv.layoutManager = LinearLayoutManager(this)

    val pkgs = Prefs.getPackages(this)
    val entries = pkgs.mapNotNull { pkg ->
      try {
        val ai = packageManager.getApplicationInfo(pkg,0)
        val label = packageManager.getApplicationLabel(ai).toString()
        AppEntry(label,pkg)
      } catch (e: PackageManager.NameNotFoundException) { null }
    }
    rv.adapter = AppAdapter(entries) { pkg ->
      packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }

    findViewById<Button>(R.id.btnOpenWeb).setOnClickListener {
      startActivity(Intent(this, KioskWebActivity::class.java))
    }
    findViewById<Button>(R.id.btnAdmin).setOnClickListener {
      startActivity(Intent(this, AdminPinActivity::class.java))
    }
  }
}

data class AppEntry(val label:String, val pkg:String)
class AppAdapter(private val items: List<AppEntry>, val onClick:(String)->Unit): RecyclerView.Adapter<AppVH>() {
  override fun onCreateViewHolder(p: ViewGroup, vt: Int)= AppVH(LayoutInflater.from(p.context).inflate(android.R.layout.simple_list_item_2,p,false))
  override fun getItemCount()= items.size
  override fun onBindViewHolder(h: AppVH, pos:Int){ val it=items[pos]; h.t1.text=it.label; h.t2.text=it.pkg; h.itemView.setOnClickListener{onClick(it.pkg)} }
}
class AppVH(v: View): RecyclerView.ViewHolder(v){ val t1:TextView=v.findViewById(android.R.id.text1); val t2:TextView=v.findViewById(android.R.id.text2) }
