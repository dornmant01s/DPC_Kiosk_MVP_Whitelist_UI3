package app.dpc.kiosk.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import app.dpc.kiosk.R
import app.dpc.kiosk.util.Prefs

class AdminPinActivity: ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_admin_pin)
    val et=findViewById<EditText>(R.id.etPin)
    findViewById<Button>(R.id.btnOk).setOnClickListener{
      if(et.text.toString()== Prefs.getPin(this)){
        startActivity(Intent(this, SettingsActivity::class.java)); finish()
      } else Toast.makeText(this,"PIN 불일치",Toast.LENGTH_SHORT).show()
    }
  }
}
