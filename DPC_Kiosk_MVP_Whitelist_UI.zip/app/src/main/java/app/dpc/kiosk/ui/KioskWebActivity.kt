package app.dpc.kiosk.ui

import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import app.dpc.kiosk.R
import app.dpc.kiosk.util.Prefs

class KioskWebActivity: ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState); setContentView(R.layout.activity_kiosk_web)
    val allowlist=Prefs.getDomains(this)
    val web=findViewById<WebView>(R.id.web)
    web.settings.javaScriptEnabled=true
    web.webViewClient=object: WebViewClient(){
      override fun shouldOverrideUrlLoading(v:WebView?, req:WebResourceRequest?):Boolean{
        val host=req?.url?.host ?: return true
        val ok=allowlist.any{ allowed-> val a=allowed.removePrefix("*."); host==a || host.endsWith("."+a) }
        return if(ok) false else { Toast.makeText(this@KioskWebActivity,"Blocked: "+host,Toast.LENGTH_SHORT).show(); true }
      }
    }
    web.loadUrl("https://www.google.com/")
  }
}
